import requests
import random

from colorama import Fore
from urllib.parse import quote

class Bot:
    def __init__(self, token: str, proxies: list):
        """discord bot"""
        self.auth = {"authorization": token}
        self.prox = random.choice(proxies)

    def proxy(self) -> dict:
        scheme = {"https": f"http://{self.prox}", "http": f"http://{self.prox}"}
        return scheme

    def refresh_proxies(self):
        f = requests.get("https://proxy.webshare.io/proxy/list/download/zajgtgpgsvsjmeontdwknnysaauczkzxhdbyyumy/-/http/port/direct/")
        prox = random.choice([x.strip() for x in f.text.strip().split("\n")])
        fp = open("proxies.txt", "w")
        fp.write("\n".join([x.strip() for x in f.text.strip().split("\n")]))
        fp.close()
        self.prox = prox
        return prox

    def join(self, invite: str):
        """Joins a server."""
        u = "https://discord.com/api/v9/"
        with requests.post(u + f"invites/{invite}", proxies=self.proxy(), headers=self.auth, stream=True) as res:
            if res.status_code == 200:
                print(Fore.GREEN + f"   Sent join to {invite}")
            else:
                print(Fore.RED + f"   Failed to join. ({res.json()})")
    
    def message(self, channel_id: int, content: str):
        """Sends a message"""
        u = "https://discord.com/api/v9/"
        d = {"content": content}
        with requests.post(u + f"channels/{channel_id}/messages", json=d, proxies=self.proxy(), headers=self.auth, stream=True) as res:
            if res.status_code == 200:
                print(Fore.GREEN + f"   Sent message '{content}'")
            else:
                print(Fore.RED + f"   Failed to message. ({res.json()})")

    def react(self, channel_id: int, message_id: int, emoji: str):
        """Sends a reaction"""
        u = "https://discord.com/api/v9/"
        p = f"channels/{channel_id}/messages/{message_id}/reactions/{quote(emoji)}/{quote('@me')}"
        with requests.put(u + p, proxies=self.proxy(), headers=self.auth, stream=True) as res:
            if res.status_code == 204:
                print(Fore.GREEN + f"   Sent reaction '{message_id}'")
            else:
                print(Fore.RED + f"   Failed to react. ({res.json()})")
    
    def leave(self, guild_id: int):
        """Leaves a server/guild"""
        u = "https://discord.com/api/v9/"
        with requests.delete(u + f"users/@me/guilds/{guild_id}", proxies=self.proxy(), headers=self.auth, stream=True) as res:
            if res.status_code == 204:
                print(Fore.GREEN + f"   Left server '{guild_id}'")
            else:
                print(Fore.RED + f"   Failed to leave. ({res.json()})")