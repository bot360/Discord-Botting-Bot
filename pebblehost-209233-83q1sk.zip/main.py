
# CONFIG ###
TOKEN = "ODcwNzcxMzM4OTQ2Njc4ODI0.YQRnAQ.yoM_oRtFaVIDgMEv2n4LC4wbgR8"
PREFIX = "!"

# developed by novuh.dev, imports
import discord
import os
from random import choice
from discord.ext import commands
from backend.bot import Bot
from concurrent.futures import ThreadPoolExecutor

if "nt" in os.name:
    os.system('cls')

# load proxies n shit
proxies = [l.strip() for l in open("proxies.txt", "r")]
tokens  = [l.strip() for l in open("tokens.txt", "r")]
botpool = [Bot(token, proxies) for token in tokens]

## actual discord bot code
client = commands.Bot(PREFIX, None)

@client.event
async def on_ready():
    print(f"   Logged into: {client.user.name}#{client.user.discriminator}\n")

@client.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"{ctx.author.mention}, please provide all arguments (see !help)")
    elif isinstance(error, commands.CommandOnCooldown):
        await ctx.send(f"{ctx.author.mention}, command is on cooldown.")
    
# commands
@commands.cooldown(1, 960, commands.cooldowns.BucketType.guild)
@client.command()
async def join(ctx, amount: int, invite: str):
    with ThreadPoolExecutor(max_workers=amount+2) as exec:
        fts = [exec.submit(choice(botpool).join, invite) for _ in range(0, amount)]
        completed = [ft.result() for ft in fts]
    
    embed=discord.Embed(title="Join", description=f"Sent {amount} joins.", color=0xff4b0f)
    embed.set_author(name="Destruction")
    embed.set_footer(text="boomraids xd")
    embed.add_field(name="Invite", value=f"{invite}", inline=True)
    await ctx.send(embed=embed)

@client.command()
async def message(ctx, amount: int, channel_id: int, *, content: str):
    with ThreadPoolExecutor(max_workers=amount+2) as exec:
        fts = [exec.submit(choice(botpool).message, channel_id, content) for _ in range(0, amount)]
        completed = [ft.result() for ft in fts]

    embed=discord.Embed(title="Message", description=f"Sent {amount} messages.", color=0xff4b0f)
    embed.set_author(name="Destruction")
    embed.set_footer(text="boomraids xd")
    embed.add_field(name="Channel ID", value=f"{channel_id}", inline=True)
    embed.add_field(name="Content", value=f"{content}", inline=True)
    await ctx.send(embed=embed)

@client.command()
async def react(ctx, amount: int, channel_id: int, message_id: int, emoji: str):
    with ThreadPoolExecutor(max_workers=amount+2) as exec:
        fts = [exec.submit(choice(botpool).react, channel_id, message_id, emoji) for _ in range(0, amount)]
        completed = [ft.result() for ft in fts]

    embed=discord.Embed(title="React", description=f"Sent {amount} reactions.", color=0xff4b0f)
    embed.set_author(name="Destruction")
    embed.set_footer(text="boomraids on top")
    embed.add_field(name="Channel ID", value=f"{channel_id}", inline=True)
    embed.add_field(name="Message ID", value=f"{message_id}", inline=True)
    embed.add_field(name="Emoji", value=f"{emoji}", inline=True)
    await ctx.send(embed=embed)

@client.command()
async def leave(ctx, amount: int, guild_id: int):
    with ThreadPoolExecutor(max_workers=amount+2) as exec:
        fts = [exec.submit(choice(botpool).leave, guild_id)]
        completed = [ft.result() for ft in fts]

    embed=discord.Embed(title="Leave", description=f"Sent {amount} leaves.", color=0xff4b0f)
    embed.set_author(name="Destruction")
    embed.set_footer(text="boomraids xd")
    embed.add_field(name="Channel ID", value=f"{guild_id}", inline=True)
    await ctx.send(embed=embed)

@client.command()
async def help(ctx):
    embed=discord.Embed(title="Help", color=0xff4b0f)
    embed.set_author(name="Destruction")
    embed.add_field(name="!join <amount> <invite>", value="Joins a server.", inline=False)
    embed.add_field(name="!message <amount> <channel_id> <message>", value="Sends x amount of messages in a channel.", inline=False)
    embed.add_field(name="!react <amount> <channel_id> <message_id> <emoji>", value="Sends x amount of reactions to a message.", inline=False)
    embed.add_field(name="!leave <amount> <guild_id>", value="Leaves a server.", inline=False)
    embed.set_footer(text="boomraids xd")
    await ctx.send(embed=embed)

@client.command()
async def bots(ctx):
    embed=discord.Embed(title="Bot list", color=0xff4b0f)
    embed.set_author(name="Destruction")
    for bot in botpool:
        token = bot.auth["authorization"]
        output = "".join([token[i] for i in range(0, 10)])
        output = output + "..."
        embed.add_field(name=f"{output}", value=f"Proxy: {bot.prox}", inline=False)
    embed.set_footer(text="boomraids xd")
    await ctx.send(embed=embed)

@client.command()
async def refresh(ctx):
    embed=discord.Embed(title="Bot list", color=0xff4b0f)
    embed.set_author(name="Destruction")
    for bot in botpool:
        b = bot.prox
        a = bot.refresh_proxies()
        z = "".join([bot.auth["authorization"][i] for i in range(0, 10)])
        embed.add_field(name=f"{z}", value=f"{b} -> {a}", inline=False)
    embed.set_footer(text="boomraids xd")
    await ctx.send(embed=embed)

client.run(TOKEN)